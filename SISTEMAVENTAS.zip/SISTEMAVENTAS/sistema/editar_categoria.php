<?php
include "includes/header.php";
include "../conexion.php";
if (!empty($_POST)) {
  $alert = "";
  if (empty($_POST['categoria'])) {
    $alert = '<p class"msg_error">Todo los campos son requeridos</p>';
  } else {
    $id_categoria = $_GET['id'];
    $nombre_categoria = $_POST['categoria'];

    $sql_update = mysqli_query($conexion, "UPDATE categoria SET nombre_categoria = '$nombre_categoria' WHERE id_categoria = $id_categoria");

    if ($sql_update) {
      $alert = '<p class"msg_save">Proveedor Actualizado correctamente</p>';
    } else {
      $alert = '<p class"msg_error">Error al Actualizar el Proveedor</p>';
    }
  }
}
// Mostrar Datos

if (empty($_REQUEST['id'])) {
  header("Location: lista_categoria.php");
  mysqli_close($conexion);
}
$id_categoria = $_REQUEST['id'];
$sql = mysqli_query($conexion, "SELECT * FROM categoria WHERE id_categoria = $id_categoria");
mysqli_close($conexion);
$result_sql = mysqli_num_rows($sql);
if ($result_sql == 0) {
  header("Location: lista_categoria.php");
} else {
  while ($data = mysqli_fetch_array($sql)) {
    $id_categoria = $data['id_categoria'];
    $categoria = $data['nombre_categoria'];
  }
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="row">
    <div class="col-lg-6 m-auto">
      <?php echo isset($alert) ? $alert : ''; ?>
      <form class="" action="" method="post">
        <input type="hidden" name="id" value="<?php echo $id_categoria; ?>">
        <div class="form-group">
          <label for="categoria">Categoria</label>
          <input type="text" placeholder="Ingrese Categoria" name="categoria" class="form-control" id="categoria" value="<?php echo $categoria; ?>">
        </div>
        <input type="submit" value="Editar Categoria" class="btn btn-primary">
      </form>
    </div>
  </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<?php include_once "includes/footer.php"; ?>